现在绝大多数电脑都是 64 位操作系统，因此双击打开 x64 的安装包安装即可。

## 阅读介绍

Ayx 博客：[免费获取在 Microsoft Store 中收费 ￥7.00 的 HEVC 视频扩展](https://imayx.top/get7yuanhevcvideoextensionforfree/)

知乎专栏：[免费获取在 Microsoft Store 中收费 ￥7.00 的 HEVC 视频扩展](https://zhuanlan.zhihu.com/p/492933007)